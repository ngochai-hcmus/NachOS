/* sort.c 
 *    Test program to sort a large number of integers.
 *
 *    Intention is to stress virtual memory system.
 *
 *    Ideally, we could read the unsorted array off of the file system,
 *	and store the result back to the file system!
 */


/*
#define UNIX
#define UNIX_DEBUG
*/

#ifdef UNIX
#include <stdio.h>
#define Exit exit
#else
#include "syscall.h"
#endif /* UNIX */

#define SIZE (1024)

int A[SIZE];	/* size of physical memory; with code, we'll run out of space!*/

void Input(int A[SIZE], int n)
{
    int i;
    PrintString("Enter elements of array: \n");
    for(i = 0; i < n; i++) {
        PrintString("A[");
        PrintNum(i);
        PrintString("] = ");
        A[i] = ReadNum();
    }
}

void Print(int A[SIZE], int n)
{
    int i;
    for(i = 0; i < n; i++)
    {
        PrintNum(A[i]);
        PrintChar(' ');
    }
    PrintChar('\n');
}

void ascBubbleSort(int A[SIZE], int n)
{
    int i, j;
    for (i = 0; i < n-1; i++){
        for (j = 0; j < n-i-1; j++){
            if (A[j] > A[j+1]){
                int temp = A[j];
                A[j] = A[j + 1];
                A[j + 1] = temp;
            }
        }
    }
}

void descBubbleSort(int A[SIZE], int n)
{
    int i, j;
    for (i = 0; i < n-1; i++){
        for (j = 0; j < n-i-1; j++){
            if (A[j] < A[j+1]){
                int temp = A[j];
                A[j] = A[j + 1];
                A[j + 1] = temp;
            }
        }
    }
}

int main()
{
    int n, choice;
    PrintString("Enter size of array: ");
    n = ReadNum();
    Input(A,n);
    PrintString("0. Ascending\n");
    PrintString("1. Descending\n");
    PrintString("Enter choice: ");
    choice = ReadNum();
    if(choice == 0){
        PrintString("Ascending array: ");
        ascBubbleSort(A,n);
        Print(A,n);
    }
    else if(choice == 1){
        PrintString("Descending array: ");
        descBubbleSort(A,n);
        Print(A,n);
    }

    Halt();
}