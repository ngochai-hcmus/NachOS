#include "syscall.h"

int main()
{
	int sourceId, destId, size, i;
	char c, s, sourceFile[100], destFile[100];

	PrintString("\nInput source file: ");
	ReadString(sourceFile, 100);
	PrintString("Input destination file: ");
	ReadString(destFile, 100);
	sourceId = Open(sourceFile, 1);

	if (sourceId == -1){
        PrintString("\nOpen ");
        PrintString(sourceFile);
        PrintString(" error!\n");
	}
	else{
        destId = Open(destFile, 0);
        if(destId == -1)
        {
            Close(destId);
            destId = Create(destFile);
            destId = Open(destFile, 0);
        }
        size = Seek(-1, sourceId);
        Seek(0, sourceId);
        Seek(0, destId);

        for (i = 0; i < size; i++){
            Read(&c, 1, sourceId);
            Write(&c, 1, destId);
        }

        PrintString("Copy successful!\n");
        Close(destId);
		Close(sourceId);
	}
	Halt();
}