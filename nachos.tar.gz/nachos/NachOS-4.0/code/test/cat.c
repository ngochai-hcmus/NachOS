#include "syscall.h"

int main()
{
	int id, size, i;
	char c, name[100];
	PrintString("Input file's name: ");
	ReadString(name, 100);

	id = Open(name, 1);
	if (id == -1){
        PrintString("Open file fail!\n");
	}
	else{
		size = Seek(-1, id);
        Seek(0, id);
        PrintString("\t\t ----- ");
        PrintString(name);
        PrintString(" -----\n");
		for (i = 0; i < size; i++){
			Read(&c, 1, id);
			PrintChar(c);
		}
		Close(id);
	}
	Halt();
}