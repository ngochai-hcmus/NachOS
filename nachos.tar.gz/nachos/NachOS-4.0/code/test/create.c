#include "syscall.h"

int main()
{
    int choice;
    PrintString("\nSelect name file to create\n");
    PrintString("1. Default: 3girls.txt\n");
    PrintString("2. Input file's name\n");
    PrintString("Enter mode: ");
    choice = ReadNum();
    if( choice == 1){
        Create("3girls.txt");
        PrintString("Create file successful!");
    }
    else if (choice == 2){
        char name[100];
        PrintString("Input your file's name: ");
        ReadString(name,100);
        Create(name);
        PrintString("Create file successful!");
    }
    else{
        PrintString("Error mode!");
    }
    Halt();
}