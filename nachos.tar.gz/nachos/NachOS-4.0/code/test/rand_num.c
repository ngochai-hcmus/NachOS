#include "syscall.h"

int main()
{
  int i;

  PrintString("Random number generated: ");
  PrintNum(RandomNum());
  PrintChar('\n');

  Halt();
}
