#include "syscall.h"

int main()
{
	char name[100];

	PrintString("Input file's name that you want to remove: ");
	ReadString(name, 100);

	if (!Remove(name))
		PrintString("Delete file successful!\n");
	else
		PrintString("Can't delete file\n");

	Halt();
}