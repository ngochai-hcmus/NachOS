#include "syscall.h"

int main()
{
  int number;

  PrintString("Enter a number: ");
  number = ReadNum();

  PrintString("You entered: ");
  PrintNum(number);
  PrintChar('\n');

  Halt();
}
