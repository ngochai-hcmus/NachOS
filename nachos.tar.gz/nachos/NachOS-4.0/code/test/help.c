#include "syscall.h"

int main()
{
    PrintString("\n\t\t ### Member's group ###  \n");
    PrintString("    Vo Ngoc Khanh Vy\t\t-\t20127099\n");
    PrintString("    Nguyen Thi Thanh Hang\t-\t20127154\n");
    PrintString("    Nguyen Thi Ngoc Hai\t\t-\t20127490\n");
 
    PrintString("\nIntroduction: \n");
    PrintString("- Help by using:\n\" ./nachos -x ../test/help \"\n");
    PrintString("- Sorting by using:\n\" ./nachos -x ../test/sort \"\n");
    PrintString("- Ascii table by using:\n\" ./nachos -x ../test/ascii \"\n");
    PrintString("- Create file by using:\n\" ./nachos -x ../test/create\"\n");
    PrintString("- Cat file by using:\n\" ./nachos -x ../test/cat \"\n");
    PrintString("- Copy file by using:\n\" ./nachos -x ../test/copy \"\n");
    PrintString("- Delete file by using:\n\" ./nachos -x ../test/delete \"\n");
    Halt();
}