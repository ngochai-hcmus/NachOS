/**************************************************************
 *
 * userprog/ksyscall.h
 *
 * Kernel interface for systemcalls
 *
 * by Marcus Voelp  (c) Universitaet Karlsruhe
 *
 **************************************************************/

#ifndef __USERPROG_KSYSCALL_H__
#define __USERPROG_KSYSCALL_H__

#include "kernel.h"
#include "synchconsole.h"
#include <limits.h>
#include <ctime>
#include <cmath>

#include "copyright.h"
#include "main.h"
#include "syscall.h"
#define MaxFileLength 32

void SysHalt()
{
    kernel->interrupt->Halt();
}

int SysAdd(int op1, int op2)
{
    return op1 + op2;
}

void IncreasePC()
{
    int counter = kernel->machine->ReadRegister(PCReg);

    kernel->machine->WriteRegister(PrevPCReg, counter);
    counter = kernel->machine->ReadRegister(NextPCReg);
    kernel->machine->WriteRegister(PCReg, counter);
    kernel->machine->WriteRegister(NextPCReg, counter + 4);
}

char *User2System(int virtAddr, int limit)
{
    int index;
    int oneChar;
    char *kernelBuf = NULL;

    kernelBuf = new char[limit + 1];

    if (kernelBuf == NULL)
        return kernelBuf;

    memset(kernelBuf, 0, limit + 1);

    for (index = 0; index < limit; index++)
    {
        kernel->machine->ReadMem(virtAddr + index, 1, &oneChar);
        kernelBuf[index] = (char)oneChar;
        if (oneChar == 0)
            break;
    }

    return kernelBuf;
}

int System2User(int virtAddr, int length, char *buffer)
{
    if (length < 0)
        return -1;
    if (length == 0)
        return length;

    int i = 0;
    int oneChar = 0;

    do
    {
        oneChar = (int)buffer[i];
        kernel->machine->WriteMem(virtAddr + i, 1, oneChar);
        i++;
    } while (i < length && oneChar != 0);

    return i;
}

void SysReadNum()
{
    char *buffer = new char[256]; // limit length of buffer

    if (buffer == NULL)
        return;

    bool isLeadingSpace = true;
    int length = 0;
    for (; length < 256; length++)
    {
        buffer[length] = kernel->synchConsoleIn->GetChar();

        if (buffer[length] == ' ' && isLeadingSpace)
        {
            length--;
            continue;
        }

        isLeadingSpace = false;

        if (buffer[length] == '\n' || buffer[length] == ' ')
            break;
    }
    buffer[length] = '\0';

    // case empty
    if (length == 0)
    {
        kernel->machine->WriteRegister(2, 0);
        delete[] buffer;
        return;
    }

    // case INT_MIN
    if (strcmp(buffer, "-2147483648") == 0)
    {
        kernel->machine->WriteRegister(2, INT_MIN);
        delete[] buffer;
        return;
    }

    bool isNegative = buffer[0] == '-';
    bool isSign = isNegative || buffer[0] == '+';
    bool isLeadingZeros = true;
    long long number = 0;

    for (int i = isSign; i < length; i++)
    {
        if (buffer[i] == '0' && isLeadingZeros)
        {
            isLeadingZeros = false;
        }
        else if (!isdigit(buffer[i]))
        {
            number = 0;
            break;
        }

        number = number * 10 + (int)(buffer[i] - '0');

        if (number > INT_MAX)
        {
            number = 0;
            break;
        }
    }

    if (isNegative)
        number *= -1;

    kernel->machine->WriteRegister(2, (int)number);
}

void SysPrintNum()
{
    long long number = kernel->machine->ReadRegister(4);

    if (number == 0)
    {
        kernel->synchConsoleOut->PutChar('0');
        return;
    }

    bool isNegative = number < 0;
    int length = (int)log10(abs(number)) + 2;

    char *buffer = new char[length + 1];

    if (buffer == NULL)
        return;

    buffer[0] = '-';

    for (int i = 1; i < length; i++)
    {
        buffer[length - i] = (char)(abs(number % 10) + '0');
        number /= 10;
    }

    for (int i = !isNegative; i < length; i++)
        kernel->synchConsoleOut->PutChar(buffer[i]);

    delete[] buffer;
}

void SysRandomNum()
{
    RandomInit((unsigned int)(time(NULL)));
    kernel->machine->WriteRegister(2, RandomNumber());
}

void SysReadChar()
{
    kernel->machine->WriteRegister(2, (int)kernel->synchConsoleIn->GetChar());
}

void SysPrintChar()
{
    kernel->synchConsoleOut->PutChar((char)kernel->machine->ReadRegister(4));
}

void SysReadString()
{
    int virAddr = kernel->machine->ReadRegister(4);
    int length = kernel->machine->ReadRegister(5);

    char *buffer = new char[length + 1];

    if (buffer == NULL)
        return;

    int i = 0;
    char c = 0;

    do
    {
        c = kernel->synchConsoleIn->GetChar();

        if (c == '\n')
            break;

        buffer[i] = c;

        i++;
    } while (i < length);

    buffer[i] = 0;

    System2User(virAddr, i, buffer);

    delete[] buffer;
}

void SysPrintString()
{
    int virAddr = kernel->machine->ReadRegister(4);

    char *buffer = User2System(virAddr, 256);

    if (buffer == NULL)
        return;

    for (int i = 0; i < 256; i++)
    {
        if (buffer[i] == 0)
            break;

        kernel->synchConsoleOut->PutChar(buffer[i]);
    }

    delete[] buffer;
}

void SysCreate()
{
    int virtAddr = kernel->machine->ReadRegister(4);       // address
    char *name = User2System(virtAddr, MaxFileLength + 1); // file's name

    if (strlen(name) == 0) // No input
    {
        printf("\n File name is not valid");
        kernel->machine->WriteRegister(2, -1);
        return;
    }

    if (name == NULL) // No enough memory to create
    {
        printf("\n Not enough memory in system");
        kernel->machine->WriteRegister(2, -1);
        delete[] name;
        return;
    }

    if (!kernel->fileSystem->Create(name, 0)) // Create error
    {
        printf("\n Error create file '%s'", name);
        kernel->machine->WriteRegister(2, -1);
        delete[] name;
        return;
    }

    kernel->machine->WriteRegister(2, 0); // Create successful
    delete[] name;
}

void SysOpen()
{
    int virtAddr = kernel->machine->ReadRegister(4);       // address
    int type = kernel->machine->ReadRegister(5);           // type of file
    char *name = User2System(virtAddr, MaxFileLength + 1); // file's name
    int freeSlot;                                          // the free slot in open table [0 -> 14]

    freeSlot = kernel->fileSystem->FindFreeSlot();
    if (freeSlot == -1)
    {
        printf("\n Full slot in open table");
        kernel->machine->WriteRegister(2, -1);
        delete[] name;
        return;
    }

    // Check each type of open file
    switch (type)
    {
    case 0: //  Read and write
    case 1: //  Read only
        if ((kernel->fileSystem->openf[freeSlot] = kernel->fileSystem->Open(name, type)))
        {
            kernel->machine->WriteRegister(2, freeSlot);
        }
        else
        { // File does not exist
            kernel->machine->WriteRegister(2, -1);
        }
        break;
    case 2:                                   //  stdin - read from console
        kernel->machine->WriteRegister(2, 0); // stdin have OpenFileId 0
        break;
    case 3:                                   //  stdout - write to console
        kernel->machine->WriteRegister(2, 1); // stdout have OpenFileId 1
        break;
    default:
        printf("\n Type is not valid");
        kernel->machine->WriteRegister(2, -1);
        break;
    }
    delete[] name;
    return;
}

void SysClose()
{
    int id = kernel->machine->ReadRegister(4); // id file
    if (id >= 0 && id <= 14)
    {
        if (kernel->fileSystem->openf[id])
        {
            delete kernel->fileSystem->openf[id];
            kernel->fileSystem->openf[id] = NULL;
            kernel->machine->WriteRegister(2, 0);
            return;
        }
    }
    kernel->machine->WriteRegister(2, -1);
}

void SysRead()
{
    int virtAddr = kernel->machine->ReadRegister(4);   // address
    int numberChar = kernel->machine->ReadRegister(5); // number of char
    int id = kernel->machine->ReadRegister(6);         // id file

    if (id < 0 || id > 14 || kernel->fileSystem->openf[id] == NULL || kernel->fileSystem->openf[id]->type == 3) // file stdout
    {
        printf("\nCan't read.");
        kernel->machine->WriteRegister(2, -1);
        return;
    }

    int Pos = kernel->fileSystem->openf[id]->GetCurrentPos(); // the current position
    int newPos;
    char *buffer = User2System(virtAddr, numberChar);

    if (kernel->fileSystem->openf[id]->type == 2) // file stdin
    {
        int size = kernel->synchConsoleIn->Read(buffer, numberChar);
        System2User(virtAddr, size, buffer);
        kernel->machine->WriteRegister(2, size);
        delete[] buffer;
        return;
    }

    if ((kernel->fileSystem->openf[id]->Read(buffer, numberChar)) > 0) // simple file
    {
        newPos = kernel->fileSystem->openf[id]->GetCurrentPos(); // the new postion
        System2User(virtAddr, newPos - Pos, buffer);             // size = new position - old position
        kernel->machine->WriteRegister(2, newPos - Pos);
    }
    else // empty file
    {
        kernel->machine->WriteRegister(2, -2);
    }
    delete[] buffer;
}

void SysWrite()
{
    int virtAddr = kernel->machine->ReadRegister(4);   // // address
    int numberChar = kernel->machine->ReadRegister(5); // number of char
    int id = kernel->machine->ReadRegister(6);         // id file

    if (id < 0 || id > 14 || kernel->fileSystem->openf[id] == NULL || kernel->fileSystem->openf[id]->type == 1 || kernel->fileSystem->openf[id]->type == 2)
    {
        printf("\n Can't write.");
        kernel->machine->WriteRegister(2, -1);
        return;
    }

    int Pos = kernel->fileSystem->openf[id]->GetCurrentPos();
    int newPos;
    char *buffer = User2System(virtAddr, numberChar);

    if (kernel->fileSystem->openf[id]->type == 0) // file read & write
    {
        if ((kernel->fileSystem->openf[id]->Write(buffer, numberChar)) > 0)
        {
            newPos = kernel->fileSystem->openf[id]->GetCurrentPos();
            kernel->machine->WriteRegister(2, newPos - Pos);
            delete[] buffer;
            return;
        }
    }
    else if (kernel->fileSystem->openf[id]->type == 3) // file stdout
    {
        int i = 0;
        while (buffer[i] != 0 && buffer[i] != '\n')
        {
            kernel->synchConsoleOut->Write(buffer + i, 1);
            i++;
        }
        buffer[i] = '\n';
        kernel->synchConsoleOut->Write(buffer + i, 1);
        kernel->machine->WriteRegister(2, i - 1);
        delete[] buffer;
        return;
    }
}

void SysSeek()
{
    int pos = kernel->machine->ReadRegister(4); // position of pointer in file
    int id = kernel->machine->ReadRegister(5);  // id file
    if (id < 0 || id > 14 || id == 0 || id == 1)
    {
        printf("\n Can't seek.");
        kernel->machine->WriteRegister(2, -1);
        return;
    }
    if (pos == -1) // -1 will be change the position to the end of file
        pos = kernel->fileSystem->openf[id]->Length();
    if (pos > kernel->fileSystem->openf[id]->Length() || pos < 0) // not valid
    {
        printf("\n Position is not valid.");
        kernel->machine->WriteRegister(2, -1);
    }
    else
    {
        kernel->fileSystem->openf[id]->Seek(pos);
        kernel->machine->WriteRegister(2, pos);
    }
}

void SysRemove()
{
    int virtAddr = kernel->machine->ReadRegister(4);       // address
    char *name = User2System(virtAddr, MaxFileLength + 1); // file's name

    // similar to SysCreate function
    if (strlen(name) == 0 || name == NULL || !kernel->fileSystem->Remove(name))
    {
        printf("\nFile name is not valid");
        kernel->machine->WriteRegister(2, -1);
        delete[] name;
        return;
    }

    kernel->machine->WriteRegister(2, 0);
    delete[] name;
}

#endif /* ! __USERPROG_KSYSCALL_H__ */
